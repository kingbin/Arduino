
#include <SoftwareSerial.h>

// analog pins 
//#define hourPin 0
#define flexSensor 0
#define minutePin 2
#define hourPinA 3
#define minutePinA 4
//#define alarmPin 4
#define snoozePin 12


// digital pins 
#define rxPin 2
#define txPin 3

//#define rxrfPin 4
//#define txrfPin 5

#define speakerPin 5

#define alarmPin 8
#define hourPin 9

#define ledPin 13


#include "WProgram.h"
void setup();
void loop();
void advanceTime();
void checkAlarm();
void onAlarm();
void checkBlindAlarm();
void onSnoozePress();
void checkButtons();
void sendData(int num);
void printWeekday (int dayNum);
void serialOutput(boolean alarm);
void lcdSetup();
void printTime(int h, int m, int mode);
void printNum(int num, int index);
void printColon(int index);
void clearSpace(int index);
void printAmPm(boolean isAm, int index);
void showSettingTime(int mode, int index);
void printAlarmSymbol(boolean isOn);
int defineCharacter(int ascii, int *data);
void playSpeaker();
int second = 45, minute = 59, hour = 11, weekday = 7; // declare time variables
int minuteA = 0, hourA = 12;

int minuteSn = 0, hourSn = 12;

boolean alarmOn = false;
byte soundAlarm = 0;
// track if the seq of the alarm is active //
byte alarmSeq = 0;
// the number of mins prior to the alarm time that blinds should go off //
int blindPrevTime = 30;

boolean minPressed = false, hourPressed = false, minPressedA = false, hourPressedA = false, alarmPressed = false, snoozePressed = false;

boolean settingTime = false, settingTimeA = false;
unsigned long lastSetA;

char snoozeTime = 1;
boolean snoozing = false;
// keep track of the last time that it was pressed //
unsigned long snoozeTracker = 0;


// speaker vars //
unsigned long speakerTime = 0;
boolean speakerHigh = false;

// flex vars //
int flexVal = 480;


// set up a new serial connection for communicating with RF receiver 
// (this also frees up Arduino's built in serial port for PC communication)
SoftwareSerial lcd =  SoftwareSerial(rxPin, txPin); 
//SoftwareSerial rfSerial =  SoftwareSerial(rxrfPin, txrfPin);


void setup() {
  
  pinMode(txPin, OUTPUT);
  pinMode(rxPin, INPUT);
  
  //pinMode(rxrfPin, INPUT);
  //pinMode(txrfPin, OUTPUT);
  
  pinMode(alarmPin, INPUT);
  pinMode(hourPin, INPUT);
  
  //rfSerial.begin(2400);
  lcdSetup();
  
  Serial.begin(2400);
  pinMode(ledPin, OUTPUT);
  pinMode(snoozePin, INPUT);
  digitalWrite(ledPin, HIGH);
  pinMode(speakerPin, OUTPUT);
  digitalWrite(speakerPin, LOW);
  
  delay(500);
  
}

void loop() {

  if (settingTime) {
    second = 0;
    //serialOutput(false);
    printTime(hour, minute, 1);
  } else if (settingTimeA) {
    //serialOutput(true);
    printTime(hourA, minuteA, 2);
  } else {
    if (millis() - lastSetA > 300) {
      advanceTime();
      checkAlarm();
    }
  }
  checkButtons(); // runs a function that checks the setting buttons
  
  // flex check //
  flexVal = (int)analogRead(flexSensor);
  //Serial.println(flexVal);
  if (flexVal >= 430) {
    sendData(15);
  } else if (flexVal <= 365) {
    sendData(5);
  } else {
    //rfSerial.print(0, BYTE);
    //Serial.print(0);
  }
}

// advance the clock time //
void advanceTime() {
    // (static variables are initialized once and keep their values between function calls)
    static unsigned long lastTick = 0; // set up a local variable to hold the last time we moved forward one second
    
    // move forward one second every 1000 milliseconds
    if (millis() - lastTick >= 1000) {
      lastTick = millis();
      second++;
      //serialOutput(false);
      printTime(hour, minute, 0);
    }

    // move forward one minute every 60 seconds
    if (second >= 60) {
      minute++;
      second = 0; // reset seconds to zero
    }

    // move forward one hour every 60 minutes
    if (minute >=60) {
      hour++;
      minute = 0; // reset minutes to zero
    }

    // move forward one weekday every 24 hours
    if (hour >= 24) {
      weekday++;
      hour = 0; // reset hours to zero
    }

    // reset weekdays on Saturday
    if (weekday >= 8) {
      weekday = 1;
    }
}

void checkAlarm() {
  if (alarmOn == false) {
    digitalWrite(speakerPin, LOW);
  }
  
  if (alarmOn == true && soundAlarm < 1 && snoozing == false) {
    if (hourA == hour) {
      if (minuteA == minute) {
        sendData(10);
        soundAlarm = 1;
      }
    }
  }
  // check for the snoozy time //
  if (snoozing == true && soundAlarm < 1) {
    if (hourSn == hour) {
      if (minuteSn == minute) {
        sendData(10);
        soundAlarm = 1;
      }
    }
  }
  
  if (soundAlarm > 0) {
    onAlarm();
  }
}

void onAlarm() {
  playSpeaker();
  sendData(10);
  if (alarmOn == false) {
    soundAlarm = 0;
    snoozing = false;
  }
  
}

void checkBlindAlarm() {
  // second=0, minute=0, hour=0, weekday=7
  // alarmMin = 0, alarmHour = 0;
  int blindMin = minuteA - blindPrevTime;
  int blindHour = hourA;
  
  if (blindMin < 0) {
    blindMin = 60 + (blindMin);
    blindHour = blindHour - 1;
    if (blindHour < 0) blindHour = 23;
  }
  
}


void onSnoozePress() {
  snoozing = true;
  digitalWrite(speakerPin, LOW);
  soundAlarm = 0;
  int tempMin = minute + snoozeTime;
  int tempHour = hour;
  
  if (tempMin >= 60) {
    tempMin = tempMin - 60;
    tempHour = tempHour + 1;
    if (tempHour >= 24) tempHour = 0;
  }
  minuteSn = tempMin;
  hourSn = tempHour;
  //Serial.print("Snoozing: ");
  //Serial.print(hourSn);
  //Serial.print(" : ");
  //Serial.println(minuteSn);
}



void checkButtons() {
  
  if (digitalRead(alarmPin) == LOW && alarmPressed == false) {
    alarmOn = !alarmOn;
    //Serial.println("Alarm button press");
    if (alarmOn == true) {
      digitalWrite(ledPin, HIGH);
      printAlarmSymbol(true);
    } else {
      digitalWrite(ledPin, LOW);
      printAlarmSymbol(false);
    }
    alarmPressed = true;
  }
  if (digitalRead(alarmPin) == HIGH) alarmPressed = false;
  
  if (digitalRead(snoozePin) == LOW && snoozePressed == false) {
    snoozeTracker = millis();
    snoozePressed = true;
    //Serial.println("Snooze button pressed Start");
    //Serial.println("Snooze button press");
    //if (soundAlarm > 0) onSnoozePress();
  }
  //if (millis() - snoozeTracker > 300 && snoozePressed == true) {
    //if (soundAlarm > 0) onSnoozePress();
    //Serial.println("Snooze button pressed");
  //}
  //Serial.println(digitalRead(snoozePin));
  
  if (digitalRead(snoozePin) == HIGH) snoozePressed = false;
  
  // check the time setting clock buttons //
  if (analogRead(minutePin) >= 1000 && minPressed == false) {
    minute++;
    if (minute >= 60) minute = 0;
    minPressed = true;
  }
  if (analogRead(minutePin) <= 10) minPressed = false;

  if (digitalRead(hourPin) == HIGH && hourPressed == false) {
    hour++;
    if (hour >= 24) hour = 0;
    hourPressed = true;
  }
  if (digitalRead(hourPin) == LOW) hourPressed = false;
  
  
  // check the alarm setting buttons //
  if (analogRead(minutePinA) >= 1000 && minPressedA == false) {
    minuteA++;
    if (minuteA >= 60) minuteA = 0;
    minPressedA = true;
  }
  if (analogRead(minutePinA) <= 10) minPressedA = false;

  if (analogRead(hourPinA) >= 1000 && hourPressedA == false) {
    hourA++;
    if (hourA >= 24) hourA = 0;
    hourPressedA = true;
  }
  if (analogRead(hourPinA) <= 10) hourPressedA = false;
  
  // check if we are setting the time //
  if (minPressed || hourPressed) {
    settingTime = true;
    snoozing = false;
  } else {
    settingTime = false;
  }
  // check if you are setting the alarm tizzime //
  if (minPressedA || hourPressedA) {
    lastSetA = millis();
    settingTimeA = true;
    snoozing = false;
  } else {
    settingTimeA = false;
  }
}

// send the data wirelessly //

void sendData(int num) {
  // N i C k
  
  Serial.print(78, BYTE);
  Serial.print(98, BYTE);
  
  Serial.print(num, BYTE);
   //rfSerial.print(78, BYTE);
   //rfSerial.print(98, BYTE);
   
   //rfSerial.print(num, BYTE);
   
   //rfSerial.print(67, BYTE);
   //rfSerial.print(97, BYTE);
   //Serial.print("sending: ");
   //Serial.println(num);
}






void printWeekday (int dayNum) {
  // print a weekday, based on the day number
  switch (dayNum) {
    case 1:
      Serial.print ("Sunday");
      break;
    case 2:
      Serial.print ("Monday");
      break;
    case 3:
      Serial.print ("Tuesday");
      break;
    case 4:
      Serial.print ("Wednesday");
      break;
    case 5:
      Serial.print ("Thursday");
      break;
    case 6:
      Serial.print ("Friday");
      break;
    case 7:
      Serial.print ("Saturday");
      break;
  }
}

void serialOutput(boolean alarm) {
  // this function creates a clock you can read through the serial port
  // your clock project will have a MUCH more interesting way of displaying the time
  // get creative!
  //printWeekday(weekday); // picks the right word to print for the weekday
  //Serial.print(", "); // a comma after the weekday
  if (alarm == false) {
    Serial.print("Clock: ");
    Serial.print(hour, DEC); // the hour, sent to the screen in decimal format
    Serial.print(":"); // a colon between the hour and the minute
    Serial.print(minute, DEC); // the minute, sent to the screen in decimal format
    Serial.print(":"); // a colon between the minute and the second
    Serial.println(second, DEC); // the second, sent to the screen in decimal format
  } else {
    Serial.print("Alarm: ");
    Serial.print(hourA, DEC); // the hour, sent to the screen in decimal format
    Serial.print(":"); // a colon between the hour and the minute
    Serial.println(minuteA, DEC); // the minute, sent to the screen in decimal format
  }
}




//int custom_0[] = { 0x15, 0x1a, 0x15, 0x1a, 0x15, 0x10, 0x10, 0x10}; // checked flag 
int custom_0[] = { 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02}; // |


/*
   _
   _|
*/
int custom_1[] = { 0x1e, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x1e}; 


/*
|_|
*/
int custom_2[] = { 0x12, 0x12, 0x12, 0x12, 0x12, 0x12, 0x12, 0x1e};


/*
 _
|_
*/
int custom_3[] = { 0x1e, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x1e};


/*
|_
*/
int custom_4[] = { 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x10, 0x1e};


/*
 _
  |
*/
int custom_5[] = { 0x1e, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02, 0x02};


/*
 _
|_|
*/
int custom_6[] = { 0x1e, 0x12, 0x12, 0x12, 0x12, 0x12, 0x12, 0x1e};


/*
 _
| |
*/
int custom_7[] = { 0x1e, 0x12, 0x12, 0x12, 0x12, 0x12, 0x12, 0x12};




void lcdSetup() {
  
  lcd.begin(9600);
  
  delay(200);
  lcd.print(124, BYTE);
  lcd.print(157, BYTE);
  //delay(500);
  
  lcd.print(0xfe, BYTE);
  lcd.print(0x01, BYTE);
  delay(200);
  
  lcd.print(0xfe, BYTE);
  lcd.print(0x0c, BYTE);
  //rfSerial.print(0xfe, BYTE);
  //rfSerial.print(0x81, BYTE);
  
  delay(200);
  defineCharacter(0, custom_0);
  delay(200);
  defineCharacter(1, custom_1);
  delay(200);
  defineCharacter(2, custom_2);
  delay(200);
  defineCharacter(3, custom_3);
  delay(200);
  defineCharacter(4, custom_4);
  delay(200);
  defineCharacter(5, custom_5);
  delay(200);
  defineCharacter(6, custom_6);
  delay(200);
  defineCharacter(7, custom_7);
  
  delay(200);
}
// mode is 0 for clock, 1 for clock setting and 2 for alarm time setting
void printTime(int h, int m, int mode) {
  int index = 0;
  boolean isAm = true;
  
  if (h > 11) {
    h = h - 12;
    isAm = false;
  } 
  if (h < 1) {
    h = 12;
  }
  
  if (h < 10) {
    clearSpace(index);
    index += 1;
    printNum(h, index);
  } else {
    //Serial.print("This is the h: ");
    //Serial.println(h);
    int rDigit = h % 10;
    int lDigit = (h - rDigit)/10;
    printNum(lDigit, index);
    index += 1;
    printNum(rDigit, index);
  }
  index += 1;
  
  printColon(index);
  
  index += 1;
  
  if (m < 10) {
    printNum(0, index);
    index += 1;
    printNum(m, index);
  } else {
    int rDigit = m % 10;
    int lDigit = (m - rDigit)/10;
    printNum(lDigit, index);
    index += 1;
    printNum(rDigit, index);
  }
  
  printAmPm(isAm, 64 + 7);
  showSettingTime(mode, 7);
  
}

void printNum(int num, int index) {
  int top = 0;
  int bot = 0;
  
  switch (num) {
    case 0:
      top = 7;
      bot = 2;
      break;
      
    case 1:
      top = 0;
      bot = 0;
      break;
    
    case 2:
      top = 1;
      bot = 4;
      break;
      
    case 3:
      top = 1;
      bot = 1;
      break;
      
    case 4:
      top = 2;
      bot = 0;
      break;
      
    case 5:
      top = 3;
      bot = 1;
      break;
      
    case 6:
      top = 4;
      bot = 2;
      break;
      
    case 7:
      top = 5;
      bot = 0;
      break;
      
    case 8:
      top = 6;
      bot = 6;
      break;
      
    case 9:
      top = 6;
      bot = 0;
      break;
      
  }
  lcd.print(0xfe, BYTE);
  lcd.print(0x80 + index, BYTE);
  lcd.print(top, BYTE);
  lcd.print(0xfe, BYTE);
  lcd.print(0x80 + 64 + index, BYTE);
  lcd.print(bot, BYTE);
}

void printColon(int index) {
  lcd.print(0xfe, BYTE);
  lcd.print(0x80 + index, BYTE);
  lcd.print(0xa5, BYTE);
  lcd.print(0xfe, BYTE);
  lcd.print(0x80 + 64 + index, BYTE);
  lcd.print(0xa5, BYTE);
}

void clearSpace(int index) {
  lcd.print(0xfe, BYTE);
  lcd.print(0x80 + index, BYTE);
  lcd.print(" ");
  lcd.print(0xfe, BYTE);
  lcd.print(0x80 + 64 + index, BYTE);
  lcd.print(" ");
}

void printAmPm(boolean isAm, int index) {
  lcd.print(0xfe, BYTE);
  lcd.print(0x80 + index, BYTE);
  if (isAm)
    lcd.print("AM");
  else 
    lcd.print("PM");
}

void showSettingTime(int mode, int index) {
  lcd.print(0xfe, BYTE);
  lcd.print(0x80 + index, BYTE);
  if (mode == 1)
    lcd.print("CLOCK");
  else if (mode == 2)
    lcd.print("ALARM");
  else 
    lcd.print("     ");
}

// print out the alarm char, to be called from the main funcs
void printAlarmSymbol(boolean isOn) {
  if (isOn) {
    lcd.print(0xfe, BYTE);
    lcd.print(0x80 + 13, BYTE);
    lcd.print("x");
    lcd.print("x");
  
    lcd.print(0xfe, BYTE);
    lcd.print(0x80 + 13 + 64, BYTE);
    lcd.print(0xdb, BYTE);
    lcd.print(0xdb, BYTE);
  } else {
    lcd.print(0xfe, BYTE);
    lcd.print(0x80 + 13, BYTE);
    lcd.print(" ");
    lcd.print(" ");
  
    lcd.print(0xfe, BYTE);
    lcd.print(0x80 + 13 + 64, BYTE);
    lcd.print(" ");
    lcd.print(" ");
    lcd.print(" ");
  }
}

// Define a custom char in lcd
int defineCharacter(int ascii, int *data) {
    int baseAddress = (ascii * 8) + 64;  
    // baseAddress = 64 | (ascii << 3);
    lcd.print(0xfe, BYTE);
    lcd.print(baseAddress, BYTE);
    for (int i = 0; i < 8; i++)
        lcd.print(data[i], BYTE);
    lcd.print(0xfe, BYTE);
    lcd.print(128, BYTE);
    return ascii;
} 






void playSpeaker() {
  
  //Serial.println((int)speakerHigh);
  if (millis() - speakerTime >= 1) {
    speakerTime = millis();
    speakerHigh = !speakerHigh;
    if  (speakerHigh == true) {
      //Serial.print("SpeakerHigh is ");
      analogWrite(speakerPin, 35);
    } else {
      digitalWrite(speakerPin, LOW);
    }
  }
}

int main(void)
{
	init();

	setup();
    
	for (;;)
		loop();
        
	return 0;
}

